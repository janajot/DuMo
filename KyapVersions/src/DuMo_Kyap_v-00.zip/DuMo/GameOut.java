package DuMo;

import javax.swing.*;
import java.awt.*;

public final class GameOut extends JPanel {
    public GameOut(int pxps) {
        setPreferredSize(new Dimension(Game.boardX * pxps, Game.boardY * pxps));
    }

    private static final Color WHITE = new Color(0xffffff);
    private static final Color BLACK = new Color(0);
    private static final Color HIGHLIGHT = new Color(0xff0000);
    private static final Color GRID = new Color(0x74938E);

    @Override
    public void paint(Graphics g) {
        final Color EDGES = Main.frame.getContentPane().getBackground();

        if (Main.settingShowGrid) {
            g.setColor(GRID);
            for (int x = 1; x < Game.boardX; x++)
                g.drawLine((getWidth() * x) / Game.boardX, 0, (getWidth() * x) / Game.boardX, getHeight());
            for (int y = 1; y < Game.boardY; y++)
                g.drawLine(0, (getHeight() * y) / Game.boardY, getWidth(), (getHeight() * y) / Game.boardY);
        }

        if (Game.isValid(Main.gH, Main.gI))
            if (Game.isHorizontal(Main.gH)) {
                paintPieceH(g, Game.curPiece, Main.gH, Main.gI, new Color((BLACK.getRGB() & 0xffffff) | 0x80_000000, true), new Color((WHITE.getRGB() & 0xffffff) | 0x80_000000, true));
            } else {
                paintPieceV(g, Game.curPiece, Main.gH, Main.gI, new Color((BLACK.getRGB() & 0xffffff) | 0x80_000000, true), new Color((WHITE.getRGB() & 0xffffff) | 0x80_000000, true));
            }

        for (int h = 0; h < Game.boardH; h += 2)
            for (int i = 0; i < Game.boardHI; i++) {
                if (Game.isPiece(h, i))
                    paintPieceH(g, Game.board[h][i], h, i, BLACK, WHITE);
            }

        for (int h = 1; h < Game.boardH; h += 2)
            for (int i = 0; i < Game.boardVI; i++) {
                if (Game.isPiece(h, i))
                    paintPieceV(g, Game.board[h][i], h, i, BLACK, WHITE);
            }

        for (int h = 0; h < Game.boardH; h += 2)
            for (int i = 0; i < Game.boardHI; i++) {
                if (Main.settingShowEdges && Game.edgeStatus[h][i] <= 2)
                    paintEdgeV(g, h, i, EDGES);
                if (Main.settingShowInvalid && Game.edgeStatus[h][i] == Piece.EDGE_INVALID)
                    paintEdgeV(g, h, i, HIGHLIGHT);
            }

        for (int h = 1; h < Game.boardH; h += 2)
            for (int i = 0; i < Game.boardVI; i++) {
                if (Main.settingShowEdges && Game.edgeStatus[h][i] <= 2)
                    paintEdgeH(g, h, i, EDGES);
                if (Main.settingShowInvalid && Game.edgeStatus[h][i] == Piece.EDGE_INVALID)
                    paintEdgeH(g, h, i, HIGHLIGHT);
            }
    }

    private void paintPieceH(Graphics g, Piece piece, int gH, int gI, Color black, Color white) {
        gH /= 2;
        int x1 = gI * getWidth() / Game.boardX;
        int y1 = gH * getHeight() / Game.boardY;
        int x2 = (gI + 2) * getWidth() / Game.boardX;
        int y2 = (gH + 1) * getHeight() / Game.boardY;

        piece.paintH(g, x1, y1, x2, y2, black, white);
    }

    private void paintPieceV(Graphics g, Piece piece, int gH, int gI, Color black, Color white) {
        gH /= 2;
        int x1 = gI * getWidth() / Game.boardX;
        int y1 = gH * getHeight() / Game.boardY;
        int x2 = (gI + 1) * getWidth() / Game.boardX;
        int y2 = (gH + 2) * getHeight() / Game.boardY;

        piece.paintV(g, x1, y1, x2, y2, black, white);
    }

    private void paintEdgeH(Graphics g, int h, int i, Color color) {
        g.setColor(color);
        h = h / 2 + 1;

        int x1 = i * getWidth() / Game.boardX;
        int y1 = h * getHeight() / Game.boardY;
        int x2 = (i + 1) * getWidth() / Game.boardX;

        g.fillRect(x1, y1 - 1, x2 - x1, 3);
    }

    private void paintEdgeV(Graphics g, int h, int i, Color color) {
        g.setColor(color);
        h /= 2;

        int y1 = h * getHeight() / Game.boardY;
        int x2 = (i + 1) * getWidth() / Game.boardX;
        int y2 = (h + 1) * getHeight() / Game.boardY;

        g.fillRect(x2 - 1, y1, 3, y2 - y1);

    }

    public int convertToRelativeX(int xM) {
        return xM - getX() - 10;
    }

    public int convertToRelativeY(int yM) {
        return yM - getY() - 30;
    }

    public void onMove() {
        double gWidth = getWidth() / (double) Game.boardX;
        double gHeight = getHeight() / (double) Game.boardY;

        int xG = Main.mouseX / (int)gWidth;
        int yG = Main.mouseY / (int)gHeight;
        double xRel = Main.mouseX % gWidth;
        double yRel = Main.mouseY % gHeight;

        boolean ur = xRel > yRel;
        boolean ul = gWidth - xRel > yRel;

        if (ur ^ ul) {
            Main.gH = yG * 2;
            Main.gI = ul ?
                    xG - 1 :
                    xG;
        } else {
            Main.gI = xG;
            Main.gH = ul ?
                    yG * 2 - 1 :
                    yG * 2 + 1;
        }
    }

}